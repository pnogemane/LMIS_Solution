﻿namespace StockSense_DotNET_API.Models
{
    public class SentimentModel
    {
    }
}

﻿namespace StockSense_DotNET_API.Models
{
    public class StockModel
    {     
        public string Symbol { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }

    }
}

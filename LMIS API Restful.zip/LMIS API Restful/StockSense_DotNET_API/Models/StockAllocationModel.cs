﻿namespace StockSense_DotNET_API.Models
{
    public class StockAllocationModel
    {
        public string Symbol { get; set; }
        public double AllocationPercentage { get; set; }
    }
}

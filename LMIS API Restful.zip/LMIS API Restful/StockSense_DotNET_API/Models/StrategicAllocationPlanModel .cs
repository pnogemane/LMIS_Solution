﻿namespace StockSense_DotNET_API.Models
{
    public class StrategicAllocationPlanModel
    {
        public string UserId { get; set; }
        public List<StockAllocationModel> Stocks { get; set; }
        public double TotalInvestment { get; set; }
        public string RiskLevel { get; set; }
        public double ProjectedReturn { get; set; }
    }
}

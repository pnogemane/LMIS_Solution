﻿using Microsoft.AspNetCore.Mvc;

namespace StockSense_DotNET_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class SocialMediaDataController : ControllerBase
    {
        [HttpGet]
        [Route("getSocialMediaData")]
        public IActionResult GetSocialMediaData()
        {
            var returnObject = "Social Media Data";
            return Ok(returnObject);
            
        }
        [HttpGet]
        [Route("getCyberSocialCompass")]
        public IActionResult GetCyberSocialCompass()
        {
            var returnObject = "Cyber Social Compass";
            return Ok(returnObject);

        }

        

    }
}

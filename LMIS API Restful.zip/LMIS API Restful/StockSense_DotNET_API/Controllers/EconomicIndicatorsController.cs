﻿using Microsoft.AspNetCore.Mvc;

namespace StockSense_DotNET_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EconomicIndicatorsController : ControllerBase
    {
        [HttpGet]
        [Route("getEconomicIndicators")]
        public IActionResult GetEconomicIndicators()
        {
            var returnObject = "Economic Indicators";
            return Ok(returnObject);
        }
    }
}

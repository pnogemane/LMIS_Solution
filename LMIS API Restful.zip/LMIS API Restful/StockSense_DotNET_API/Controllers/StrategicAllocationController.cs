﻿using Microsoft.AspNetCore.Mvc;
using StockSense_DotNET_API.Models;

namespace StockSense_DotNET_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StrategicAllocationController : ControllerBase
    {
        private static List<StrategicAllocationPlanModel> 
            AllocationPlans = new List<StrategicAllocationPlanModel>();

        [HttpGet]
        [Route("getstrategicallocation")]
        public IActionResult GetStrategicAllocation()
        {
            var allocationPlan = new
            {
                totalInvestment = 10000,
                allocationPlan = new[]
                {
            new
            {
                stock = new { symbol = "AAPL", name = "Apple Inc." },
                expectedReturn = 0.08,
                suggestedAllocationPercentage = 40,
                suggestedAmount = 4000
            },
            new
            {
                stock = new { symbol = "GOOGL", name = "Alphabet Inc." },
                expectedReturn = 0.07,
                suggestedAllocationPercentage = 30,
                suggestedAmount = 3000
            },
            new
            {
                stock = new { symbol = "AMZN", name = "Amazon.com, Inc." },
                expectedReturn = 0.06,
                suggestedAllocationPercentage = 20,
                suggestedAmount = 2000
            },
            new
            {
                stock = new { symbol = "TSLA", name = "Tesla, Inc." },
                expectedReturn = 0.09,
                suggestedAllocationPercentage = 10,
                suggestedAmount = 1000
            }
        },
                totalExpectedReturn = 0.075,
                estimatedAnnualReturn = 750
            };

            return Ok(allocationPlan); // Return the allocation plan as a JSON response
        }



        [HttpGet]
        [Route("GetAllocation")]

        public IActionResult GetAllocation()
        {
            string userId = "Should be passed in";
            var allocation = AllocationPlans.FirstOrDefault(a => a.UserId == userId);
            if (allocation == null)
                return NotFound("Allocation plan not found.");

            return Ok(allocation);
        }

        [HttpPost]
        public IActionResult CreateOrUpdateAllocation([FromBody] StrategicAllocationPlanModel allocationPlan)
        {
            var existingPlan = AllocationPlans.FirstOrDefault(a => a.UserId == allocationPlan.UserId);
            if (existingPlan != null)
            {
                existingPlan.Stocks = allocationPlan.Stocks;
                existingPlan.TotalInvestment = allocationPlan.TotalInvestment;
                existingPlan.RiskLevel = allocationPlan.RiskLevel;
                existingPlan.ProjectedReturn = allocationPlan.ProjectedReturn;
            }
            else
            {
                AllocationPlans.Add(allocationPlan);
            }

            return Ok(allocationPlan);
        }

        [HttpDelete("{userId}")]
        public IActionResult DeleteAllocation(string userId)
        {
            var allocation = AllocationPlans.FirstOrDefault(a => a.UserId == userId);
            if (allocation == null)
                return NotFound("Allocation plan not found.");

            AllocationPlans.Remove(allocation);
            return Ok("Allocation plan deleted successfully.");
        }
    }
}

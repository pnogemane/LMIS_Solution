﻿using Microsoft.AspNetCore.Mvc;

namespace StockSense_DotNET_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PreferencesController : ControllerBase
    {
        [HttpGet]
        [Route("getPreferences")]
        public IActionResult GetPreferences()
        {
            var returnObject = "Preferences";
            return Ok(returnObject);
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using StockSense_DotNET_API.Models;

namespace StockSense_DotNET_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StocksController : ControllerBase
    {
        [HttpGet]
        [Route("getstocks")]
        public IActionResult GetStocks()
        {
            // Sample data: replace this with your logic to get stocks
            var stocks = new List<StockModel>
            {
                new StockModel { Symbol = "AAPL", Name = "Apple Inc.", Price = 150.00 },
                new StockModel { Symbol = "GOOGL", Name = "Alphabet Inc.", Price = 2800.00 },
                new StockModel { Symbol = "AMZN", Name = "Amazon.com, Inc.", Price = 3300.00 }
            };

            return Ok(stocks); // Return the list of stocks as a JSON response
        }
    }
}

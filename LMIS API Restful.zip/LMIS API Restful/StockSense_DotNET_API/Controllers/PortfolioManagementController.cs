﻿using Microsoft.AspNetCore.Mvc;

namespace StockSense_DotNET_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PortfolioManagementController : ControllerBase
    {
        [HttpGet]
        [Route("getPortfolioManagement")]
        public IActionResult GetPortfolioManagement()
        {
            var returnObject = "Portfolio Management";
            return Ok(returnObject);
        }
    }
}

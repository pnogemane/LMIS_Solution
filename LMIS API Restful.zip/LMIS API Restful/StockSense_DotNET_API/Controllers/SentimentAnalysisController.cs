﻿using Microsoft.AspNetCore.Mvc;


namespace StockSense_DotNET_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SentimentAnalysisController : ControllerBase
    {
        [HttpGet]
        [Route("getSentimentAnalysis")]
        public IActionResult GetSentimentAnalysis()
        {
            var returnObject = "Sentiment Analysis";
            return Ok(returnObject);
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;


namespace StockSense_DotNET_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NewsEndpointsController : ControllerBase
    {
        [HttpGet]
        [Route("getNews")]
        public IActionResult GetNews()
        {
            var returnObject = "News Updates";
            return Ok(returnObject);
        }
    }
}

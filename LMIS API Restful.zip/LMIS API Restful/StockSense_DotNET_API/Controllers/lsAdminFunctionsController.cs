﻿using Microsoft.AspNetCore.Mvc;

namespace StockSense_DotNET_API.Controllers
{
    public class lsAdminFunctionsController : Controller
    {

        [HttpGet]
        [Route("getAllCourses")]

        public IActionResult GetAllCourses()
        {
            var returnObject = "All Courses";
            return Ok(returnObject);
        }

        [HttpGet]
        [Route("getAllStudents")]

        public IActionResult GetAllStudents()
        {
            var returnObject = "All Students";
            return Ok(returnObject);
        }






        public IActionResult Index()
        {
            return View();
        }
    }
}
